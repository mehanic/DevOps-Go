CREATE TABLE "products"(
    "id" uuid PRIMARY KEY,
    "name" VARCHAR ,
    "barcode" VARCHAR ,
    "price" NUMERIC ,
    "category_id" uuid,
    "image_url" VARCHAR,
    "updated_at" timestamp
);